
## Version 1.5

* Fix divide by 0 error when there are 0 KVM entries to write

## Version 1.4

* Add parallel KVM write mode, with a flag to specify the degree of parallelism
* Add trace mode to emit individual KVM write timings
* Add "inject fault" mode to simulate errors in KVM writes

## Version 1.3

* Each attempt to write a KVM entry will now be retried up to two times in the case of failure (the client has been experiencing transient 401s in testing against their org(s))

## Version 1.2

* Add `-i` mode to read the legacy KVM data from a json file instead of a KVM

## Version 1.1

* Fix to ignore all expected key types (locks, id sequences) when parsing KVM entries

## Version 1.0

* Initial release
