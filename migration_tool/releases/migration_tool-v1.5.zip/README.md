
# Background 

This migration tool is designed to migrate the proxy's KVM data to the new format as of "v2" of the proxy that was delivered to the customer on 3.22.25.

# Requirements

* Python3 (this script is tested on Python version Python 3.12.9)
* A valid authentication token for a user with IAM authorization to read and write KVMs and KVM entries in the org(s) in question. In local testing this token was derived using `gcloud auth print-access-token` (see [gcloud CLI](https://cloud.google.com/sdk/docs/install))

# Upgrade procedure

1. Disable the old version of the proxy
2. Run this migration script
3. Install and enable the new version of the proxy

# Running this script

Below is a sample invocation of the script:
```
./migrate_kvm.py -o apigee-ngsaas-prod-test1 -a $(gcloud auth print-access-token) -p 20
Migrating from source org apigee-ngsaas-prod-test1 KVM to dest org apigee-ngsaas-prod-test1 KVM
Current state of kvm saved to kvm-backup-2025-05-22-21:05:06.json
refs found: 735; orphaned appgroup refs: 182; orphaned dev refs: 1
Do you want to delete and recreate your KVM in apigee-ngsaas-prod-test1? (Y/N)y
Deleted KVM.
Recreated KVM.
Importing data to KVM.
Writing 370 appgroup entries with parallelism of 20
progress: 20 / 370 (0.033/s)
progress: 40 / 370 (0.026/s)
<snip>
progress: 360 / 370 (0.017/s)
progress: 370 / 370 (0.018/s)
finished. time elapsed: 6.6 seconds
Writing 540 developer entries with parallelism of 20
progress: 20 / 540 (0.02/s)
progress: 40 / 540 (0.019/s)
<snip>
progress: 540 / 540 (0.014/s)
progress: 540 / 540 (0.014/s)
finished. time elapsed: 7.5 seconds
Migration completed.
```

Notes:
* The script can be run with no arguments to get a list of valid arguments.
* A "Do you want to delete and recreate" checkpoint happens before any data is destroyed. You can answer "n" or "N" and abort.
* The script output will include a tally of "orphaned references". These are not a sign of error, they are expected in some cases when appgroups or developers have been deleted.
* Use of the `- p` option is recommended to speed up the KVM write phase (in the example above a parallism factor of 20 is used)

# Input modes

## Read from source KVM (default mode)

* Migrates KVM data from the specified source org
* The current state of the KVM is backed up to a json file in the local directory with the name `kvm-backup-datetime.json`

## Read from json file (-i flag)

* Migrates KVM data from the specified local json file; can be used to resume an interruped migration

