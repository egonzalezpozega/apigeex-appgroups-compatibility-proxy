#!/usr/bin/env python3

import argparse
import legacy_processor
import util
import kvm_api
from datetime import datetime
from kvm_api import ApiContext, KvmId
from typing import List
from appgroup_developers import AppgroupDevelopers
from developer_appgroups import DeveloperAppgroups


_api_base = "https://apigee.googleapis.com/v1"
_kvm_id = KvmId(
    proxy_name="companies-compatibility-proxy", kvm_name="apigee-companies-compat"
)
_par_level = None
_update_interval = 50


def overwrite_kvm(
    api_context: ApiContext,
    agds: List[AppgroupDevelopers],
    dags: List[DeveloperAppgroups],
) -> None:
    delete = input(
        f"Do you want to delete and recreate your KVM in {api_context.org}? (Y/N)"
    )
    if delete.upper() != "Y":
        print("aborting")
        return

    kvm_api.delete_kvm(api_context, _kvm_id)
    print(f"Deleted KVM.")

    kvm_api.create_kvm(api_context, _kvm_id)
    print(f"Recreated KVM.")

    print(f"Importing data to KVM.")
    print(f"Writing {len(agds)} appgroup entries with parallelism of {_par_level}")
    util.parallel_run_with_updates(
        fun=kvm_api.write_kvm_entry,
        data=[
            (api_context, _kvm_id, item.key, util.zip_and_encode(item.serialize()))
            for item in agds
        ],
        par_level=_par_level,
        update_interval=_update_interval,
    )

    print(f"Writing {len(dags)} developer entries with parallelism of {_par_level}")
    util.parallel_run_with_updates(
        fun=kvm_api.write_kvm_entry,
        data=[
            (api_context, _kvm_id, item.key, util.zip_and_encode(item.serialize()))
            for item in dags
        ],
        par_level=_par_level,
        update_interval=_update_interval,
    )


def migrate_from_file(filepath: str, dest: ApiContext):
    agds, dags = legacy_processor.parse_legacy_json_from_file(filepath)
    legacy_processor.hydrate_and_prune(agds, dags)
    overwrite_kvm(api_context=dest, agds=agds, dags=dags)
    print("Migration completed.")


def migrate_from_kvm(src: ApiContext, dest: ApiContext):
    run_str = datetime.now().strftime("%Y-%m-%d-%H:%M:%S")
    kvm_dump_loc = str.format(f"kvm-backup-{run_str}.json")

    src_json_str = kvm_api.read_all_kvm_entries_to_json_str(src, _kvm_id)
    util.write_string_to_file(kvm_dump_loc, src_json_str)
    print(
        f"Current state of {src.org_root}/{_kvm_id.rel_path} KVM saved to {kvm_dump_loc}."
    )

    migrate_from_file(kvm_dump_loc, dest)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-o",
        "--org",
        required=True,
        help="The organization to perform the migration on",
        type=str,
    )
    parser.add_argument(
        "-a",
        "--auth_token",
        required=True,
        help="The auth token used for access to call apis on your behalf",
    )
    parser.add_argument(
        "-do",
        "--alt_dest_org",
        help="Alternate org to write the updated kvm data to",
    )
    parser.add_argument(
        "-t",
        "--trace",
        action="store_true",
        help="Enabled tracing of API activity",
    )
    parser.add_argument(
        "-f",
        "--inject_faults",
        action="store_true",
        help="Inject occasional faults in upstream API calls",
    )
    parser.add_argument(
        "-i",
        "--input_file",
        help="Use to migrate from the provided file instead of a KVM",
        type=str,
    )
    parser.add_argument(
        "-p",
        "--parallel",
        help="KVM write entry parallelization level (default 1)",
        type=int,
    )
    args = parser.parse_args()

    par_level = args.parallel if args.parallel is not None else 1
    par_level = max(par_level, 1)
    global _par_level
    _par_level = par_level

    src = ApiContext(
        api=_api_base,
        org=args.org,
        authtoken=args.auth_token,
        trace=args.trace,
        inject_faults=args.inject_faults,
    )
    dest = ApiContext(
        api=_api_base,
        org=args.alt_dest_org if args.alt_dest_org is not None else args.org,
        authtoken=args.auth_token,
        trace=args.trace,
        inject_faults=args.inject_faults,
    )

    if args.input_file is not None:
        print(
            f"Migrating from source file {args.input_file} to dest org {dest.org} KVM"
        )
        migrate_from_file(args.input_file, dest)
    else:
        print(f"Migrating from source org {src.org} KVM to dest org {dest.org} KVM")
        migrate_from_kvm(src, dest)


if __name__ == "__main__":
    main()
