import requests
import json
import time
import util
from urllib.parse import quote


class ApiContext:
    def __init__(self, api, org, authtoken, trace, inject_faults):
        self.api = api
        self.org = org
        self.authtoken = authtoken
        self.trace = trace
        self.inject_faults = inject_faults
        self.org_root = f"{self.api}/organizations/{self.org}"

    def headers(self):
        return {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + self.authtoken,
        }

    def trace_event(self, str):
        if not self.trace:
            return
        print("api trace: " + str)


class KvmId:
    def __init__(self, proxy_name, kvm_name):
        # kvm can have 3 parent types, for now assume it's always a proxy
        self.proxy_name = proxy_name
        self.kvm_name = kvm_name
        self.rel_path_root = f"apis/{self.proxy_name}/keyvaluemaps"
        self.rel_path = f"apis/{self.proxy_name}/keyvaluemaps/{self.kvm_name}"


def create_kvm(api: ApiContext, id: KvmId):
    url = f"{api.org_root}/{id.rel_path_root}"
    payload = {"name": id.kvm_name}
    response = requests.post(url, headers=api.headers(), json=payload)
    if not response.ok:
        raise Exception(
            f"Failed creating KVM, API Code: {response.status_code}, Response: {response.text}"
        )


def delete_kvm(api: ApiContext, id: KvmId):
    url = f"{api.org_root}/{id.rel_path}"
    response = requests.delete(url, headers=api.headers())
    if not response.ok:
        raise Exception(
            f"Failed deleting KVM, API Code: {response.status_code}, Response: {response.text}"
        )


def iterate_kvm_entries(api: ApiContext, id: KvmId):
    nextPageToken = "start"
    while nextPageToken != "":
        query = ""
        if nextPageToken != "" and nextPageToken != "start":
            query = "&pageToken=" + quote(nextPageToken)
        url = f"{api.org_root}/{id.rel_path}/entries?pageSize=100" + query

        start_time = time.perf_counter()
        response = requests.get(url, headers=api.headers())
        end_time = time.perf_counter()
        api.trace_event(
            f"read page of kvm entries in {round(end_time - start_time, 3)}s"
        )
        if not response.ok:
            raise Exception(
                f"Failed retrieving kvm page, API Code: {response.status_code}, Response: {response.text}"
            )

        try:
            data = response.json()
        except json.JSONDecodeError:
            raise Exception("Failed to decode JSON response")
        nextPageToken = data["nextPageToken"]
        value = data["keyValueEntries"]
        for item in value:
            yield item


def read_all_kvm_entries_to_json_str(api: ApiContext, id: KvmId) -> str:
    output = ""
    for item in iterate_kvm_entries(api, id):
        nvalue = item["name"]
        vvalue = item["value"]
        # some values were not base64 encoded but rather json objects
        # this escapes their values
        # In the case of a backup and restore where we dont convert/migrate data
        vvalue = vvalue.replace('"', '\\"')
        output = output + ' { "name": "' + nvalue + '", "value": "' + vvalue + '" },'
    if output != "":
        output = output.rstrip(",")
        output = '{ "keyValueEntries": [' + output + "]}"
    return output


def read_kvm_entry(api: ApiContext, id: KvmId, name: str) -> str:
    url = f"{api.org_root}/{id.rel_path}/entries/{name}"

    start_time = time.perf_counter()
    response = requests.get(url, headers=api.headers())
    end_time = time.perf_counter()
    api.trace_event(f"read kvm entry in {round(end_time - start_time, 3)}s")

    if not response.ok:
        raise Exception(
            f"Failed reading entry: {name}, API Code: {response.status_code}, Response: {response.text}"
        )
    try:
        return response.json()
    except json.JSONDecodeError:
        raise Exception("Failed to decode JSON response")


# has retry
def write_kvm_entry(api: ApiContext, id: KvmId, name: str, value: str) -> None:

    def attempt_write() -> requests.Response:
        url = f"{api.org_root}/{id.rel_path}/entries"
        payload = {"name": name, "value": value}
        start_time = time.perf_counter()
        response = requests.post(url, headers=api.headers(), json=payload)
        end_time = time.perf_counter()
        api.trace_event(f"wrote kvm entry in {round(end_time - start_time, 3)}s")
        return response

    def retry_hook(response: requests.Response):
        print(f"got {response.status_code} trying to insert entry {name}, retrying")

    def fault_hook():
        # because the call actually succeeded, need to rename the key to avoid a conflict
        nonlocal name
        name += "-retry"

    response = util.request_with_retry_and_fault_injection(
        req_fun=attempt_write,
        retries=2,
        retry_hook_fun=retry_hook,
        fault_freq=50 if api.inject_faults else None,
        fault_hook_fun=fault_hook,
    )

    if not response.ok:
        raise Exception(
            f"Failed inserting entry: {name}, API Code: {response.status_code}, Response: {response.text}"
        )
