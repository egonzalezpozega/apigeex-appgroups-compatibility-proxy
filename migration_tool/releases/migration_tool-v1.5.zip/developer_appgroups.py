from typing import List
import util
import json


class DeveloperAppgroups:
    def __init__(self, key, developer_id, encoded_dev_id, appgroups):
        # the kvm key, not part of de/serialization
        self.key = key
        # on read from legacy, this is derived from the kvm key
        self.developer_id = developer_id
        # read from legacy for mapping purposes, not written to new format
        self.encoded_dev_id = encoded_dev_id
        self.appgroups: List[DeveloperAppgroup] = appgroups

    def __str__(self):
        return str.format(
            f"{self.developer_id} - {self.encoded_dev_id} - {len(self.appgroups)}"
        )

    # str should already be base64-decoded.
    @staticmethod
    def deserialize_from_legacy_format(key, bytes):
        id = key.removeprefix("developer_").removesuffix("_appgroups")
        if id == key:
            raise Exception(f"key {key} not in expected format")

        readIndex = 0
        formatVersion = util.threeBytesToInt(bytes, readIndex)
        if formatVersion != 1:
            raise ValueError(f"Invalid Format version {formatVersion}")
        readIndex += 3
        encodedDevId = util.threeBytesToInt(bytes, readIndex)
        readIndex += 3

        ags: List[DeveloperAppgroup] = []

        while readIndex < len(bytes):
            agId = util.threeBytesToInt(bytes, readIndex)
            ags.append(DeveloperAppgroup(appgroup_id="", encoded_ag_id=agId, ref_id=""))
            readIndex += 3

        return DeveloperAppgroups(
            key=key, developer_id=id, encoded_dev_id=encodedDevId, appgroups=ags
        )

    def serialize(self) -> str:
        return json.dumps(self, cls=DagKvmEncoder, indent=4)


class DeveloperAppgroup:
    def __init__(self, appgroup_id, encoded_ag_id, ref_id):
        # this is not present in legacy and will have to be hydrated after read
        self.appgroup_id = appgroup_id
        # not written to new format
        self.encoded_ag_id = encoded_ag_id
        self.ref_id = ref_id


class DagKvmEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, DeveloperAppgroups):
            return {
                "developerId": obj.developer_id,
                "associatedAppGroups": obj.appgroups,
            }
        elif isinstance(obj, DeveloperAppgroup):
            return {
                "id": obj.appgroup_id,
                "refId": obj.ref_id,
            }
        return super().default(obj)
