import util
import base64
from typing import Tuple, List
from appgroup_developers import (
    AppgroupDeveloper,
    AppgroupDevelopers,
)
from developer_appgroups import (
    DeveloperAppgroup,
    DeveloperAppgroups,
)


def _debug(str, level="debug"):
    if level == "trace":
        return
    print(str)


def parse_legacy_json_from_file(
    filepath,
) -> Tuple[List[AppgroupDevelopers], List[DeveloperAppgroups]]:
    data = util.read_file_to_json(filepath)
    agds: List[AppgroupDevelopers] = []
    dags: List[DeveloperAppgroups] = []
    items = data["keyValueEntries"]
    for item in items:
        # print(item["name"])
        key = str(item["name"])
        value = str(item["value"])
        if key == "appgroup_id" or key == "developer_id" or key.endswith("_lock"):
            # not of interest to us
            continue
        elif key.startswith("appgroup_"):
            _debug(f"parsing appgroup with key {key}", "trace")
            agds.append(
                AppgroupDevelopers.deserialize_from_legacy_format(
                    key, base64.b64decode(value)
                )
            )
        elif key.startswith("developer_"):
            _debug(f"parsing developer with key {key}", "trace")
            dags.append(
                DeveloperAppgroups.deserialize_from_legacy_format(
                    key, base64.b64decode(value)
                )
            )
        else:
            raise Exception("key not in expected format: " + key)
    return agds, dags


# hydrate ids / add ref ids / prune orphan refs; modifies the data in place
def hydrate_and_prune(
    agds: List[AppgroupDevelopers], dags: List[DeveloperAppgroups]
) -> None:
    ags_by_encoded_id = {ag.encoded_ag_id: ag for ag in agds}
    devs_by_encoded_id = {dev.encoded_dev_id: dev for dev in dags}

    orphaned_devrefs_count = 0
    orphaned_agrefs_count = 0
    found_refs_count = 0

    for ag in agds:
        pruned_refs: List[AppgroupDeveloper] = []

        for dev_ref in ag.developers:
            dev = devs_by_encoded_id.get(dev_ref.encoded_dev_id)

            if dev is None:
                _debug(
                    f"Appgroup {ag.appgroup_id}'s reference to developer with encoded id {dev_ref.encoded_dev_id} not found, removing reference",
                    "trace",
                )
                orphaned_devrefs_count += 1
                continue

            # we've found the counterpart dev, now find its back reference
            ag_ref = next(
                (x for x in dev.appgroups if x.encoded_ag_id == ag.encoded_ag_id), None
            )

            if ag_ref is None:
                _debug(
                    f"Appgroup {ag.appgroup_id}'s reference to developer {dev.developer_id} is not reciprocated, removing reference",
                    "trace",
                )
                orphaned_devrefs_count += 1
                continue

            _debug("reference FOUND", "trace")
            found_refs_count += 1

            # hydrate both references and add the ref id
            dev_ref.developer_id = dev.developer_id
            ag_ref.appgroup_id = ag.appgroup_id
            new_ref_id = util.gen_ref_id(5)
            dev_ref.ref_id = new_ref_id
            ag_ref.ref_id = new_ref_id

            pruned_refs.append(dev_ref)

        ag.developers = pruned_refs

    # all reciprocal refs have been identified. so on the dev side we just need to prune.
    for dev in dags:
        pruned_refs: List[DeveloperAppgroup] = []

        for ag_ref in dev.appgroups:
            ag = ags_by_encoded_id.get(ag_ref.encoded_ag_id)
            if ag is None:
                _debug(
                    f"Developer {dev.developer_id}'s reference to appgroup with encoded id {ag_ref.encoded_ag_id} not found, removing reference",
                    "trace",
                )
                orphaned_agrefs_count += 1
                continue
            if len(ag_ref.ref_id) == 0:
                _debug(
                    f"Developer {dev.developer_id}'s reference to appgroup {ag.appgroup_id} is not reciprocated, removing reference",
                    "trace",
                )
                orphaned_agrefs_count += 1
                continue
            pruned_refs.append(ag_ref)

        dev.appgroups = pruned_refs

    _debug(
        f"refs found: {found_refs_count}; orphaned appgroup refs: {orphaned_agrefs_count}; orphaned dev refs: {orphaned_devrefs_count}"
    )

    return agds, dags
