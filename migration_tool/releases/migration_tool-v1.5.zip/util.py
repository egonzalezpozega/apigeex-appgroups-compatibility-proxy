import json
import gzip
import io
import base64
import random
import time
import multiprocessing
import requests

_refchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"


def read_file_to_json(filepath):
    with open(filepath, "r") as file:
        data = json.load(file)
        if not isinstance(data, dict):
            raise Exception("json not in expected format")
        return data


def write_string_to_file(filepath, str):
    with open(filepath, "w") as file:
        file.write(str)


def read_null_terminated_string(data: bytes, encoding="utf-8") -> str:
    """
    Reads a null-terminated string from bytes.

    Args:
        data: The bytes containing the null-terminated string.
        encoding: The encoding to use for decoding the string (default: 'utf-8').

    Returns:
        The string before the first null character, or an empty string if no null
        character is found.
    """
    if b"\x00" not in data:
        return ""

    return data.split(b"\x00", 1)[0].decode(encoding)


def threeBytesToInt(byteArr, offset):
    return int.from_bytes(byteArr[offset : offset + 3])


def gen_ref_id(len):
    return "".join([random.choice(_refchars) for _ in range(len)])


def zip_and_encode(data: str) -> str:
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb") as f:
        f.write(data.encode("utf-8"))
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def inject_fault(out_of) -> True:
    return random.randrange(1, out_of) == out_of - 1


class ParallelProgressCounter:
    def __init__(self, goal, update_interval):
        self.goal = goal
        self.update_interval = update_interval
        self.lock = multiprocessing.Lock()
        self.counter = multiprocessing.Value("i", 0)
        self.start_time = time.perf_counter()

    def update(self, incr=1):
        with self.lock:
            self.counter.value += incr
            num = self.counter.value
        if incr == 0 or num % self.update_interval == 0:
            elapsed = time.perf_counter() - self.start_time
            rate = elapsed / num
            print(f"progress: {num} / {self.goal} ({round(rate, 3)}/s)")
        if incr == 0:
            print(f"finished. time elapsed: {round(elapsed, 1)} seconds")

    def finish(self):
        self.update(0)


def _init_pool_process_globals(the_fun, the_counter):
    global fun
    fun = the_fun
    global counter
    counter = the_counter


def _parallel_run_wrapper(*args):
    fun(*args)
    counter.update()


def parallel_run_with_updates(fun, data, par_level, update_interval):
    if len(data) == 0:
        return
    counter = ParallelProgressCounter(goal=len(data), update_interval=update_interval)
    with multiprocessing.Pool(
        processes=par_level,
        initializer=_init_pool_process_globals,
        initargs=(fun, counter),
    ) as pool:
        pool.starmap(_parallel_run_wrapper, data)
        counter.finish()


def request_with_retry_and_fault_injection(
    req_fun, retries, retry_hook_fun, fault_freq, fault_hook_fun
) -> requests.Response:
    attempts = 0
    while True:
        response = req_fun()

        if response.ok:
            if fault_freq is not None and inject_fault(fault_freq):
                response.status_code = 401
                fault_hook_fun()
            else:
                # success
                return response

        if attempts < retries:
            retry_hook_fun(response)
            attempts += 1
        else:
            return response
