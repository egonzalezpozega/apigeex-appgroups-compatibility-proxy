from typing import List
import util
import json


class AppgroupDevelopers:
    def __init__(self, key, appgroup_id, encoded_ag_id, developers):
        # the kvm key, not part of de/serialization
        self.key = key
        # on read from legacy, this is derived from the kvm key
        self.appgroup_id = appgroup_id
        # read from legacy for mapping purposes, not written to new format
        self.encoded_ag_id = encoded_ag_id
        self.developers: List[AppgroupDeveloper] = developers

    def __str__(self):
        return str.format(
            f"{self.appgroup_id} - {self.encoded_ag_id} - {len(self.developers)}"
        )

    # str should already be base64-decoded.
    def deserialize_from_legacy_format(key, bytes):
        id = key.removeprefix("appgroup_").removesuffix("_developers")
        if id == key:
            raise Exception(f"key {key} not in expected format")

        readIndex = 0
        formatVersion = util.threeBytesToInt(bytes, readIndex)
        if formatVersion != 1:
            raise ValueError(f"Invalid Format version {formatVersion}")
        readIndex += 3
        encodedId = util.threeBytesToInt(bytes, readIndex)
        readIndex += 3
        numRoles = util.threeBytesToInt(bytes, readIndex)
        readIndex += 3

        roles = []
        for i in range(numRoles):
            rolestr = util.read_null_terminated_string(bytes[readIndex:])
            roles.append(rolestr)
            readIndex += len(roles[-1]) + 1

        devs: List[AppgroupDeveloper] = []
        while readIndex < len(bytes):
            devId = util.threeBytesToInt(bytes, readIndex)
            readIndex += 3
            roleIdx = util.threeBytesToInt(bytes, readIndex)
            readIndex += 3
            devs.append(
                AppgroupDeveloper(
                    developer_id="",
                    encoded_dev_id=devId,
                    role=roles[roleIdx],
                    ref_id="",
                )
            )

        return AppgroupDevelopers(
            key=key, appgroup_id=id, encoded_ag_id=encodedId, developers=devs
        )

    def serialize(self) -> str:
        return json.dumps(self, cls=AgdKvmEncoder, indent=4)


class AppgroupDeveloper:
    def __init__(self, developer_id, encoded_dev_id, role, ref_id):
        # this is not present in legacy and will have to be hydrated after read
        self.developer_id = developer_id
        # not written to new format
        self.encoded_dev_id = encoded_dev_id
        self.role = role
        self.ref_id = ref_id


class AgdKvmEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, AppgroupDevelopers):
            return {
                "appGroupId": obj.appgroup_id,
                "associatedDevelopers": obj.developers,
            }
        elif isinstance(obj, AppgroupDeveloper):
            return {
                "id": obj.developer_id,
                "role": obj.role,
                "refId": obj.ref_id,
            }
        return super().default(obj)
